function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);

}

function draw() {
	ellipse(random, random, 20, 20);
}